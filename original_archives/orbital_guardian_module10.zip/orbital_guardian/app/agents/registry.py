"""
Registry: the single place that decides, for each of the 9 upstream agents,
whether to call this repo's reference/stub implementation or a teammate's
real one.

How a teammate swaps in their real agent:
    1. Write a module anywhere that exposes a `run(...)` function with the
       SAME signature as the stub it replaces (see the docstring at the top
       of each stub module in this package -- signatures are documented
       there, matching the build plan's JSON contracts exactly).
    2. Import it here and set REGISTRY["<agent_name>"] = their_module.run.
    3. Nothing else in the orchestrator changes -- pipeline.py and every
       route in app/main.py only ever call REGISTRY[name](...), never the
       stub modules directly.

This is what makes agents 1-9 truly pluggable behind the JSON contracts, per
the build plan's core design rule (§0): "any agent can be swapped for a stub
... while another team member builds a different agent in parallel."
"""
from __future__ import annotations
from typing import Callable

from app.agents import (
    tracking,
    prediction,
    collision_detection,
    risk_assessment,
    maneuver,
    mission_constraint,
    decision,
    negotiation,
    explanation,
)

REGISTRY: dict[str, Callable] = {
    "tracking": tracking.run,
    "prediction": prediction.run,
    "collision_detection": collision_detection.run,
    "risk_assessment": risk_assessment.run,
    "maneuver": maneuver.run,
    "mission_constraint": mission_constraint.run,
    "decision": decision.run,
    "negotiation": negotiation.run,
    "explanation": explanation.run,
}

# Flip these to True once a *real* implementation is registered for that
# agent, purely for display purposes in the dashboard ("stub" vs "real"
# badge next to each row of the agent log / architecture panel).
IS_REAL: dict[str, bool] = {name: False for name in REGISTRY}


def get(agent_name: str) -> Callable:
    if agent_name not in REGISTRY:
        raise KeyError(f"No agent registered under name '{agent_name}'")
    return REGISTRY[agent_name]


def register(agent_name: str, fn: Callable, is_real: bool = True) -> None:
    """Called by a teammate's real-agent module to take over from the stub."""
    if agent_name not in REGISTRY:
        raise KeyError(f"Unknown agent name '{agent_name}' -- check registry.py's known agent list")
    REGISTRY[agent_name] = fn
    IS_REAL[agent_name] = is_real
