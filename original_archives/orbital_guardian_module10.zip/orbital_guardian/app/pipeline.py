"""
The orchestration graph. This is the only file allowed to know the *order*
agents run in -- every route in main.py calls into functions here rather
than chaining agents inline, so the call order is defined exactly once.

Two entry points:
  - run_full_pipeline(...): the "Start Simulation" one-click demo path,
    tracking -> prediction -> collision detection -> (risk -> maneuver ->
    constraint -> decision -> explanation) per flagged conjunction.
  - run_maneuver_chain(...): the targeted re-plan path used by
    POST /maneuvers/{primary}, e.g. after an operator command changes
    constraints and only one object needs to be re-evaluated.

Every agent call is wrapped so its output is validated against the Pydantic
schema for that contract BEFORE it's written to the state store or handed to
the next step (see `_validate`). A schema violation logs a "failed" event
and stops just that branch -- it does not crash the whole run, per the
failure-isolation rule in the implementation doc (§8): one bad/unfinished
agent should not blank the rest of the dashboard.
"""
from __future__ import annotations
import asyncio
from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, ValidationError

from app.agents.registry import get as get_agent
from app.state import store, events
from app import schemas
from app.config import DEFAULT_PC_THRESHOLD_TARGET


async def _call(agent_name: str, fn, *args, summary: str = "", **kwargs) -> Any:
    await events.emit(agent_name, "started", summary or f"{agent_name} invoked")
    try:
        result = await asyncio.to_thread(fn, *args, **kwargs)
    except Exception as e:
        await events.emit(agent_name, "failed", f"{type(e).__name__}: {e}")
        raise
    await events.emit(agent_name, "completed", summary or f"{agent_name} done")
    return result


def _validate(model: type[BaseModel], data: Any, agent_name: str) -> Any:
    try:
        model.model_validate(data)
    except ValidationError as e:
        raise ValueError(f"{agent_name} output failed schema validation: {e}") from e
    return data


async def run_full_pipeline(object_count: int = 50, window_hours: float = 24.0,
                             guaranteed_conjunctions: int = 3,
                             pc_threshold_target: float = DEFAULT_PC_THRESHOLD_TARGET) -> dict:
    epoch = datetime.now(timezone.utc)

    # ---- 1. Tracking ----
    objects = await _call(
        "tracking", get_agent("tracking"),
        mode="synthetic", object_count=object_count,
        guaranteed_conjunctions=guaranteed_conjunctions, epoch_utc=epoch,
        summary=f"generating synthetic fleet of {object_count} objects",
    )
    store.clear_objects()
    for obj in objects:
        _validate(schemas.TrackedObject, obj, "tracking")
        store.save_object(obj)

    # ---- 2. Prediction ----
    ephemerides = []
    prediction_fn = get_agent("prediction")
    for obj in objects:
        eph = await asyncio.to_thread(prediction_fn, obj, window_hours, 60)
        _validate(schemas.EphemerisRecord, eph, "prediction")
        store.save_ephemeris(eph)
        ephemerides.append(eph)
    await events.emit("prediction", "completed",
                       f"propagated {len(ephemerides)} objects over {window_hours}h")

    # ---- 3. Collision detection ----
    pairs_screened = len(objects) * (len(objects) - 1) // 2
    cd_out = await _call(
        "collision_detection", get_agent("collision_detection"),
        ephemerides, {"start_utc": epoch.isoformat(), "end_utc": ""},
        summary=f"screened {pairs_screened} possible pairs",
    )
    conjunctions = cd_out["conjunctions"]
    store.save_conjunctions(conjunctions)
    await events.emit("collision_detection", "completed",
                       f"screened {pairs_screened} possible pairs -> {len(conjunctions)} candidates flagged")

    # ---- 4-7. Risk -> Maneuver -> Constraint -> Decision, per flagged conjunction ----
    decisions = []
    risk_fn, maneuver_fn = get_agent("risk_assessment"), get_agent("maneuver")
    constraint_fn, decision_fn = get_agent("mission_constraint"), get_agent("decision")
    explanation_fn = get_agent("explanation")
    global_constraints = store.get_constraints("global") or {}

    for conj in conjunctions:
        risk_input = {
            **conj,
            "combined_hard_body_radius_m": 15.0,
        }
        risk = await _call(
            "risk_assessment", risk_fn, risk_input, epoch,
            summary=f"{conj['primary_id']} vs {conj['secondary_id']}",
        )
        _validate(schemas.RiskRecord, risk, "risk_assessment")
        store.save_risk(risk)
        await events.emit("risk_assessment", "completed",
                           f"{risk['primary_id']} vs {risk['secondary_id']}: "
                           f"Pc={risk['pc']:.2e}, tier={risk['risk_tier']}")

        if risk["risk_tier"] in ("GREEN",):
            decision = {"primary_id": risk["primary_id"], "decision": "NO_ACTION",
                        "selected_maneuver": None, "confidence_pct": 98.0}
            store.save_decision(decision)
            decisions.append(decision)
            continue

        maneuver_input = {
            "primary_id": risk["primary_id"],
            "risk_tier": risk["risk_tier"],
            "pc": risk["pc"],
            "tca_utc": conj["tca_utc"],
            "mean_motion_rad_s": 0.0011,
            "pc_threshold_target": pc_threshold_target,
            "miss_distance_km": risk["miss_distance_km"],
        }
        man_out = await _call("maneuver", maneuver_fn, maneuver_input,
                               summary=f"searching Δv candidates for {risk['primary_id']}")
        _validate(schemas.ManeuverCandidatesResponse, man_out, "maneuver")
        store.save_maneuver_candidates(risk["primary_id"], man_out)

        constraints = {**global_constraints, **(store.get_constraints(risk["primary_id"]) or {})}
        eval_out = await _call(
            "mission_constraint", constraint_fn,
            risk["primary_id"], man_out["candidates"], constraints,
            summary=f"checking {len(man_out['candidates'])} candidates against mission constraints",
        )
        _validate(schemas.EvaluatedCandidatesResponse, eval_out, "mission_constraint")
        store.save_evaluated_candidates(risk["primary_id"], eval_out)

        decision = await _call(
            "decision", decision_fn,
            risk["primary_id"], risk["risk_tier"], man_out["candidates"], eval_out["evaluated"],
            pc_threshold_target,
            summary=f"decision for {risk['primary_id']}",
        )
        _validate(schemas.Decision, decision, "decision")
        store.save_decision(decision)
        decisions.append(decision)
        await events.emit("decision", "completed",
                           f"{decision['primary_id']}: {decision['decision']}")

        report = await _call("explanation", explanation_fn, "report",
                              decision=decision, risk=risk,
                              summary=f"drafting report for {risk['primary_id']}")
        store.save_constraints(f"report:{risk['primary_id']}", report)

    return {
        "objects_tracked": len(objects),
        "pairs_screened": pairs_screened,
        "conjunctions_flagged": len(conjunctions),
        "decisions": decisions,
    }


async def run_maneuver_chain(primary_id: str, secondary_id: str | None, risk_tier: str,
                              pc_threshold_target: float, constraints: dict) -> dict:
    """Targeted re-plan for one object, used by POST /maneuvers/{primary}."""
    risk = None
    if secondary_id:
        risk = store.get_risk(primary_id, secondary_id)
    if risk is None:
        # fall back to the highest-Pc risk record on file for this primary
        candidates = [r for r in store.all_risks() if r["primary_id"] == primary_id]
        risk = max(candidates, key=lambda r: r["pc"], default=None)
    if risk is None:
        raise ValueError(f"No risk record on file for {primary_id} -- run /conjunctions and /risk first")

    maneuver_fn, constraint_fn, decision_fn = (
        get_agent("maneuver"), get_agent("mission_constraint"), get_agent("decision"),
    )

    maneuver_input = {
        "primary_id": primary_id,
        "risk_tier": risk_tier or risk["risk_tier"],
        "pc": risk["pc"],
        "tca_utc": store.get_conjunction(primary_id, risk["secondary_id"])["tca_utc"],
        "mean_motion_rad_s": 0.0011,
        "pc_threshold_target": pc_threshold_target,
        "miss_distance_km": risk["miss_distance_km"],
    }
    man_out = await _call("maneuver", maneuver_fn, maneuver_input,
                           summary=f"re-planning Δv candidates for {primary_id}")
    _validate(schemas.ManeuverCandidatesResponse, man_out, "maneuver")
    store.save_maneuver_candidates(primary_id, man_out)

    eval_out = await _call("mission_constraint", constraint_fn,
                            primary_id, man_out["candidates"], constraints,
                            summary=f"checking {len(man_out['candidates'])} candidates against constraints")
    _validate(schemas.EvaluatedCandidatesResponse, eval_out, "mission_constraint")
    store.save_evaluated_candidates(primary_id, eval_out)

    decision = await _call("decision", decision_fn,
                            primary_id, risk_tier or risk["risk_tier"],
                            man_out["candidates"], eval_out["evaluated"], pc_threshold_target,
                            summary=f"decision for {primary_id}")
    _validate(schemas.Decision, decision, "decision")
    store.save_decision(decision)

    return {"candidates": man_out["candidates"], "evaluated": eval_out["evaluated"], "decision": decision}
