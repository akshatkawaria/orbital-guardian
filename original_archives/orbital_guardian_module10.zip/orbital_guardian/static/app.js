// Orbital Guardian dashboard -- plain JS, no build step.
// Talks to the Module 10 FastAPI orchestrator documented in app/main.py.

const logEl = document.getElementById("log");
const riskTbody = document.querySelector("#riskTable tbody");
const decisionTbody = document.querySelector("#decisionTable tbody");
const catalogTbody = document.querySelector("#catalogTable tbody");
const pairsScreenedEl = document.getElementById("pairsScreened");
const canvas = document.getElementById("orbitCanvas");
const ctx = canvas.getContext("2d");

let riskByPair = {};   // "PRIMARY_vs_SECONDARY" -> risk record
let objectRiskTier = {}; // object_id -> worst risk tier seen (for plot coloring)

// ---------------------------------------------------------------------
// Agent Activity Log (SSE)
// ---------------------------------------------------------------------
function connectLog() {
  const es = new EventSource("/agent-log");
  es.addEventListener("agent_event", (e) => {
    const evt = JSON.parse(e.data);
    appendLogEntry(evt);
  });
  es.onerror = () => {
    // EventSource auto-reconnects; nothing to do here for a hackathon build.
  };
}

function appendLogEntry(evt) {
  const div = document.createElement("div");
  div.className = `log-entry status-${evt.status}`;
  const time = (evt.ts || "").split("T")[1]?.replace("Z", "") || "";
  div.innerHTML = `<span class="ts">${time}</span><span class="agent">${evt.agent}</span>${escapeHtml(evt.detail)}`;
  logEl.appendChild(div);
  // cap log length in the DOM so a long-running demo doesn't bloat the page
  while (logEl.children.length > 400) logEl.removeChild(logEl.firstChild);
}

function escapeHtml(s) {
  const d = document.createElement("div");
  d.innerText = s;
  return d.innerHTML;
}

// ---------------------------------------------------------------------
// Catalog + orbit plot
// ---------------------------------------------------------------------
async function loadCatalog() {
  const res = await fetch("/catalog");
  const data = await res.json();
  catalogTbody.innerHTML = "";
  for (const obj of data.objects) {
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${obj.object_id}</td><td>${obj.object_type}</td>
      <td>${obj.mean_elements.inclination_deg.toFixed(2)}</td>
      <td>${obj.mean_elements.mean_motion_rev_day.toFixed(3)}</td>`;
    catalogTbody.appendChild(tr);
  }
  return data.objects;
}

async function loadEphemeridesAndDraw() {
  const objects = await loadCatalog();
  if (objects.length === 0) return;

  const points = [];
  for (const obj of objects.slice(0, 60)) {   // cap for plot readability
    const res = await fetch(`/propagate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ object_ids: [obj.object_id], window_hours: 2, step_seconds: 300 }),
    }).catch(() => null);
    if (!res || !res.ok) continue;
    const data = await res.json();
    const eph = data.ephemerides?.[0];
    if (eph) points.push({ id: obj.object_id, ephemeris: eph.ephemeris });
  }
  drawOrbitPlot(points);
}

function tierColor(tier) {
  return { GREEN: "#3ecf8e", YELLOW: "#e8c547", ORANGE: "#e8924a", RED: "#e85c4a" }[tier] || "#4a5568";
}

function drawOrbitPlot(points) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const scale = (Math.min(canvas.width, canvas.height) / 2 - 20) / 7500; // km -> px, ~7000km max radius
  const cx = canvas.width / 2, cy = canvas.height / 2;

  // Earth
  ctx.beginPath();
  ctx.arc(cx, cy, 6378.137 * scale, 0, Math.PI * 2);
  ctx.fillStyle = "#132030";
  ctx.fill();
  ctx.strokeStyle = "#2a3a4a";
  ctx.stroke();

  for (const p of points) {
    const tier = objectRiskTier[p.id];
    ctx.strokeStyle = tier ? tierColor(tier) : "#2a3644";
    ctx.beginPath();
    p.ephemeris.forEach((pt, i) => {
      const x = cx + pt.r_km[0] * scale;
      const y = cy - pt.r_km[1] * scale;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.stroke();

    const last = p.ephemeris[p.ephemeris.length - 1];
    ctx.fillStyle = tier ? tierColor(tier) : "#7c8797";
    ctx.beginPath();
    ctx.arc(cx + last.r_km[0] * scale, cy - last.r_km[1] * scale, 2.5, 0, Math.PI * 2);
    ctx.fill();
  }
}

// ---------------------------------------------------------------------
// Risk + decision tables
// ---------------------------------------------------------------------
async function refreshRiskTable() {
  const res = await fetch("/risks");
  const data = await res.json();
  riskTbody.innerHTML = "";
  objectRiskTier = {};
  for (const r of data.risks) {
    riskByPair[`${r.primary_id}_vs_${r.secondary_id}`] = r;
    const prevTier = objectRiskTier[r.primary_id];
    if (!prevTier || tierRank(r.risk_tier) > tierRank(prevTier)) objectRiskTier[r.primary_id] = r.risk_tier;

    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${r.primary_id}</td><td>${r.secondary_id}</td>
      <td>${(r.time_to_tca_minutes ?? "").toString()} min</td>
      <td>${r.miss_distance_km.toFixed(2)}</td>
      <td>${r.pc.toExponential(2)}</td>
      <td><span class="badge badge-${r.risk_tier}">${r.risk_tier}</span></td>`;
    riskTbody.appendChild(tr);
  }

  const conjRes = await fetch("/conjunctions");
  const conjData = await conjRes.json();
  pairsScreenedEl.textContent = `${conjData.pairs_screened} pairs screened -> ${conjData.conjunctions.length} flagged`;
}

function tierRank(t) { return { GREEN: 0, YELLOW: 1, ORANGE: 2, RED: 3 }[t] ?? -1; }

async function refreshDecisionTable() {
  const res = await fetch("/decisions");
  const data = await res.json();
  decisionTbody.innerHTML = "";
  for (const d of data.decisions) {
    const m = d.selected_maneuver;
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${d.primary_id}</td><td>${d.decision}</td>
      <td>${m ? m.dv_ms.toFixed(2) : "—"}</td>
      <td>${m ? m.direction : "—"}</td>
      <td>${m ? m.predicted_miss_km.toFixed(1) : "—"}</td>
      <td>${m ? m.fuel_cost_pct.toFixed(2) : "—"}</td>`;
    decisionTbody.appendChild(tr);
  }
}

// ---------------------------------------------------------------------
// Controls
// ---------------------------------------------------------------------
document.getElementById("startBtn").addEventListener("click", async () => {
  const object_count = parseInt(document.getElementById("objCount").value, 10) || 50;
  const window_hours = parseFloat(document.getElementById("windowHours").value) || 24;
  await fetch("/simulate/start", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ object_count, window_hours, guaranteed_conjunctions: 3 }),
  });
  // poll the derived tables while the background pipeline runs; the log
  // itself updates live over SSE regardless of this poll.
  pollWhileRunning();
});

let pollHandle = null;
function pollWhileRunning() {
  if (pollHandle) clearInterval(pollHandle);
  let ticks = 0;
  pollHandle = setInterval(async () => {
    await refreshRiskTable();
    await refreshDecisionTable();
    ticks += 1;
    if (ticks > 40) clearInterval(pollHandle);   // ~40s safety cutoff for a hackathon-scale run
  }, 1000);
}

document.getElementById("sendCommand").addEventListener("click", async () => {
  const text = document.getElementById("operatorText").value.trim();
  if (!text) return;
  const res = await fetch("/operator-command", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text }),
  });
  const data = await res.json();
  document.getElementById("constraintsOut").textContent = JSON.stringify(data.constraints, null, 2);
});

// ---------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------
connectLog();
loadCatalog();
refreshRiskTable();
refreshDecisionTable();
